
public class Buffer2014302580201 {
	private Teacher2014302580201[] teacherArray = new Teacher2014302580201[15];
	private int num = 0;

	public int getnum() {
		return num;
	}

	public synchronized void setTeacher(Teacher2014302580201 a) throws InterruptedException {
		while (num == 15) {
			wait();
		}
		teacherArray[num] = a;
		num++;
		notifyAll();
	}

	public synchronized Teacher2014302580201 getTeacher() throws InterruptedException {
		while (num == 0) {
			wait();
		}
		Teacher2014302580201 b = teacherArray[num - 1];
		num--;
		notifyAll();
		return b;
	}
}
