import java.sql.SQLException;

public class Main2014302580201 {
	public static void main(String[] args) {
		// ���߳�
		long time1 = System.currentTimeMillis();
		Buffer2014302580201 buffer = new Buffer2014302580201();
		Spider2014302580201 spider = new Spider2014302580201(buffer);
		htmlJsoup2014302580201 html = new htmlJsoup2014302580201(buffer);
		spider.start();
		html.start();
		long time2 = System.currentTimeMillis();
		System.out.println("���߳�ʱ��:" + (time2 - time1));
		// ���߳�
		long time3 = System.currentTimeMillis();
		GetTeacher2014302580201 getTeacher = new GetTeacher2014302580201();
		Database2014302580201 database = new Database2014302580201("teachers");
		Teacher2014302580201 teacher;
		String[] name = getTeacher.getname();
		String[] massage;
		for (int i = 0; i < 100; i++) {
			teacher = new Teacher2014302580201(name[i] + ".html");
			massage = teacher.getTeacherMassage();
			try {
				database.writeDatabase(massage);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		long time4 = System.currentTimeMillis();
		System.out.println("���߳�ʱ��:" + (time4 - time3));
	}
}
