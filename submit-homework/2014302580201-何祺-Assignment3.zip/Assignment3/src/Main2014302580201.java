import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580201 {

	public static void main(String[] args) {
		multiThread();
		singleThread();
	}

	public static void multiThread() {
		long time1 = System.currentTimeMillis();
		Buffer2014302580201 buffer = new Buffer2014302580201();
		Spider2014302580201 spider = new Spider2014302580201(buffer);
		htmlJsoup2014302580201 html = new htmlJsoup2014302580201(buffer);
		spider.start();
		html.start();
		long time2 = System.currentTimeMillis();
		System.out.println("���߳�ʱ��:" + (time2 - time1));
	}

	public static void singleThread() {
		long time1 = System.currentTimeMillis();
		GetTeacher2014302580201 getTeacher = new GetTeacher2014302580201();
		Database2014302580201 database = new Database2014302580201("teachers");
		Teacher2014302580201 teacher;
		String[] name = getTeacher.getname();
		String[] massage;
		for (int i = 0; i < 100; i++) {
			teacher = new Teacher2014302580201(name[i] + ".html");
			massage = teacher.getTeacherMassage();
			try {
				database.writeDatabase(massage);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		long time2 = System.currentTimeMillis();
		System.out.println("���߳�ʱ��:" + (time2 - time1));
	}
}

class Teacher2014302580201 {
	private int Size = 5;
	private String[] teacher = new String[Size];

	public Teacher2014302580201(String html) {
		try {
			readHTML(html);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String[] getTeacherMassage() {
		return teacher;
	}

	public void readHTML(String html) throws IOException {
		// ��ȡ����html�ļ��������Խ���
		File input = new File(html);
		Document doc = Jsoup.parse(input, "UTF-8");
		// ��ѡ�����﷨������Ҫ�Ľ�ʦ��Ϣ�浽Elements������,��ʦ��Ϣ��<div
		// class=col-xs-7>��ǩ��,���н�ʦ������<h3>��ǩ��,������Ϣ��<p>��ǩ��
		Elements text = doc.select("div.col-xs-7");
		Elements text1 = text.select("h3");
		Elements text2 = text.select("p");
		teacher[0] = text1.text();
		// ����text2�ڵ�Element
		for (Element text0 : text2) {
			// ����ý�ʦ�Ľ�ʦ���,�о�����
			String str = text0.toString();
			str = str.replace(" ", "");
			str = str.replace("<p>", "");
			str = str.replace("</p>", "");
			String[] str1 = str.split("<br>");
			for (int i = 0; i < 4; i++) {
				teacher[i + 1] = str1[i];
			}
		}
	}
}

class GetTeacher2014302580201 {
	private int Size = 100;
	private String[] name = new String[Size];
	private String[] html = new String[Size];

	public GetTeacher2014302580201() {
		try {
			readMainHTML();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String[] getname() {
		return name;
	}

	public void readMainHTML() throws IOException {
		Document doc = Jsoup.connect("http://staff.whu.edu.cn/").get();
		Elements text = doc.select("p");
		Elements text1 = doc.select("strong");
		Elements text2 = text.select("a[href]");
		int i = 0;
		for (Element text0 : text1) {
			name[i] = text0.text();
			i++;
		}
		i = 0;
		for (Element text0 : text2) {
			html[i] = text0.attr("abs:href");
			html[i] = html[i].replaceAll(" ", "%20");
			i++;

		}
		for (int k = 0; k < 100; k++) {
			HttpRequest2014302580201 response = HttpRequest2014302580201.get(html[k]);
			if (response.ok()) {
				response.receive(new File(name[k] + ".html"));
			}
		}
	}
}
//Buffer����������Teacher�����
class Buffer2014302580201 {
	private Teacher2014302580201[] teacherArray = new Teacher2014302580201[15];
	private int num = 0;

	public int getnum() {
		return num;
	}

	public synchronized void setTeacher(Teacher2014302580201 a) throws InterruptedException {
		while (num == 15) {
			wait();
		}
		teacherArray[num] = a;
		num++;
		notifyAll();
	}

	public synchronized Teacher2014302580201 getTeacher() throws InterruptedException {
		while (num == 0) {
			wait();
		}
		Teacher2014302580201 b = teacherArray[num - 1];
		num--;
		notifyAll();
		return b;
	}
}
//��ȡ100��ʦ����ҳ
class Spider2014302580201 extends Thread {
	private GetTeacher2014302580201 getTeacher = new GetTeacher2014302580201();
	private Teacher2014302580201 teacher;
	private Buffer2014302580201 buffer;
	private String[] name = new String[100];

	public Spider2014302580201(Buffer2014302580201 buffer) {
		name = getTeacher.getname();
		this.buffer = buffer;
	}

	public void run() {
		for (int i = 0; i < 100; i++) {
			teacher = new Teacher2014302580201(name[i] + ".html");
			try {
				buffer.setTeacher(teacher);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
//��100����ʦ����Ϣд�����ݿ�
class htmlJsoup2014302580201 extends Thread {
	private Buffer2014302580201 buffer;
	private Database2014302580201 database = new Database2014302580201("teacher");
	private Teacher2014302580201 teacher;

	public htmlJsoup2014302580201(Buffer2014302580201 buffer) {
		this.buffer = buffer;
	}

	public void run() {
		for (int i = 0; i < 100; i++) {
			try {
				teacher = buffer.getTeacher();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				database.writeDatabase(teacher.getTeacherMassage());
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
//Database�����н�����д�����ݿ�ķ���
class Database2014302580201 {
	private String table;

	public Database2014302580201(String table) {
		this.table = table;
	}

	private String url = "jdbc:mysql://localhost:3306/sqltest?" + "user=root&password=heqi0313";

	public void writeDatabase(String[] a) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(url);
		Statement state = conn.createStatement();
		String sql = "insert into " + table + "(name,position,direction,email,phone)" + "values('" + a[0] + "','" + a[1]
				+ "','" + a[2] + "','" + a[3] + "','" + a[4] + "')";
		state.executeUpdate(sql);
		state.close();
		conn.close();
	}
}
