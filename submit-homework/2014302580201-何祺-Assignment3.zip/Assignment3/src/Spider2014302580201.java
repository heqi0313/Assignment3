
public class Spider2014302580201 extends Thread{
	private GetTeacher2014302580201 getTeacher = new GetTeacher2014302580201();
	private Teacher2014302580201 teacher;
	private Buffer2014302580201 buffer;
	private String[] name = new String[100];

	public Spider2014302580201(Buffer2014302580201 buffer) {
		name = getTeacher.getname();
		this.buffer = buffer;
	}

	public void run() {
		for (int i = 0; i < 100; i++) {
			teacher = new Teacher2014302580201(name[i] + ".html");
			try {
				buffer.setTeacher(teacher);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
