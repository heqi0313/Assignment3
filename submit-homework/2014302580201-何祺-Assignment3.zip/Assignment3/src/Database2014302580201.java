import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database2014302580201 {
	private String table;

	public Database2014302580201(String table) {
		this.table = table;
	}

	private String url = "jdbc:mysql://localhost:3306/sqltest?" + "user=root&password=heqi0313";

	public void writeDatabase(String[] a) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(url);
		Statement state = conn.createStatement();
		String sql = "insert into " + table + "(name,position,direction,email,phone)" + "values('" + a[0] + "','" + a[1]
				+ "','" + a[2] + "','" + a[3] + "','" + a[4] + "')";
		state.executeUpdate(sql);
		state.close();
		conn.close();
	}
}
