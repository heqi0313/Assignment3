import java.io.File;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GetTeacher2014302580201 {
	private int Size = 100;
	private String[] name = new String[Size];
	private String[] html = new String[Size];

	public GetTeacher2014302580201() {
		try {
			readMainHTML();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String[] getname() {
		return name;
	}

	public void readMainHTML() throws IOException {
		Document doc = Jsoup.connect("http://staff.whu.edu.cn/").get();
		Elements text = doc.select("p");
		Elements text1 = doc.select("strong");
		Elements text2 = text.select("a[href]");
		int i = 0;
		for (Element text0 : text1) {
			name[i] = text0.text();
			i++;
		}
		i = 0;
		for (Element text0 : text2) {
			html[i] = text0.attr("abs:href");
			html[i] = html[i].replaceAll(" ", "%20");
			i++;

		}
		for (int k = 0; k < 100; k++) {
			HttpRequest2014302580201 response = HttpRequest2014302580201.get(html[k]);
			if (response.ok()) {
				response.receive(new File(name[k] + ".html"));
			}
		}
	}
}
