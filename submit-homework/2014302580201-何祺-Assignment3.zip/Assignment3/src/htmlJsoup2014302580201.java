import java.sql.SQLException;

public class htmlJsoup2014302580201 extends Thread{
	private Buffer2014302580201 buffer;
	private Database2014302580201 database = new Database2014302580201("teacher");
	private Teacher2014302580201 teacher;

	public htmlJsoup2014302580201(Buffer2014302580201 buffer) {
		this.buffer = buffer;
	}

	public void run() {
		for (int i = 0; i < 100; i++) {
			try {
				teacher = buffer.getTeacher();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				database.writeDatabase(teacher.getTeacherMassage());
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
